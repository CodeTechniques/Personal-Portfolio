let dot1 = document.querySelector('.dot1');
let dot2 = document.querySelector('.dot2');
let dot3 = document.querySelector('.dot3');
let dot4 = document.querySelector('.dot4');
let body = document.querySelector('body');
dot1.onclick = function(){
    body.classList.toggle('change1');
}
dot2.onclick = function(){
    body.classList.toggle('change2');
}
dot3.onclick = function(){
    body.classList.toggle('change3');
}
dot4.onclick = function(){
    body.classList.toggle('change4');
}
